function popup(){
	data="<div style='text-align:left'>"+<?php echo json_encode($data);?>+"</div>";
		sweetAlert({title:'Event Data',html:data,'padding':'0','width':'1000px','background':'#bdbdbd',confirmButtonText: 'More'},function(){document.location.href="http://www.google.com";});
}

